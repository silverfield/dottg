rm tikz2pdff.tex
rm tikz2pdf_temp.pdf
python tikz2pdf -so $1
rm tikz2pdff.tex

